#ifndef TASK_2_H_
#define TASK_2_H_

#include <stdio.h>

void init_LEDs(void);
void task2(void);

#endif // TASK_2_H_