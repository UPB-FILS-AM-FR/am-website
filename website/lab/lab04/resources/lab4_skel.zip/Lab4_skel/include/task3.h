#ifndef TASK_3_H_
#define TASK_3_H_

#include <stdio.h>

void timer1_init(void);
void timer0_init(void);
void adc_free_running_init(void);
void configure_adc_channel(uint8_t channel);
void task3(void);

#endif // TASK_3_H_