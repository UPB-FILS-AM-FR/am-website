#ifndef TASK_4_H_
#define TASK_4_H_

#include <stdio.h>

void Timer1_init_systicks(void);
void adc_init_8bit(void);
uint8_t myAnalogRead_8bit(uint8_t channel);
void task4(void);

#endif // TASK_4_H_