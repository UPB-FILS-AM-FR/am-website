#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "usart.h"
#include "adc.h"
#include "task4.h"

volatile uint32_t systicks = 0;

void Timer1_init_systicks(void)
{
    TCCR1A = 0;
    TCCR1B = 0;

    TCCR1B |= (1 << WGM12);

    TCCR1B |= (1 << CS11);

    TIMSK1 |= (1 << OCIE1A);

    OCR1A = 1500;
}

ISR(TIMER1_COMPA_vect)
{
    systicks++;
}

// TODO: Task 4: Init ADC with 8bit precision
void adc_init_8bit(void)
{
    
}

// TODO: Task 4: Read the 8bit adc value. Hint: It is in the upper half of ADC register
uint8_t myAnalogRead_8bit(uint8_t channel)
{
    channel &= 0b00000111;
}

void task4(void)
{
    Timer1_init_systicks();
    uint32_t elapsed_time = 0;
    uint32_t start;
    uint32_t end;
    int16_t i = 0;

    start = systicks;
    for (i = 0; i < 10000; i++)
    {
        myAnalogRead(0);
    }
    end = systicks;
    elapsed_time = end - start;
    printf("Last ADC value: %d\n", myAnalogRead(0));
    printf("Elapsed time for 10-bit ADC: %ld ticks\n", elapsed_time);

    adc_init_8bit();
    start = systicks;
    for (i = 0; i < 10000; i++)
    {
        myAnalogRead_8bit(0);
    }
    end = systicks;
    elapsed_time = end - start;
    printf("Last ADC value: %d\n", myAnalogRead_8bit(0) * 4);
    printf("Elapsed time for 8-bit ADC: %ld ticks\n", elapsed_time);
    while (1);
}