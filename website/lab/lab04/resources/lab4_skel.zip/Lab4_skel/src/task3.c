#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "usart.h"
#include "adc.h"
#include "task3.h"

// TODO [task3]: Implement the following function for free running ADC
void adc_free_running_init(void)
{
  // Set ADC to free running mode

  // Enable ADC interrupt

  // Enable auto-triggering
}

// TODO [task3]: Implement the following function to configure the ADC channel
// HINT: similar to myAnalogRead function in adc.c
void configure_adc_channel(uint8_t channel)
{
  // Force input channel to be between 0 and 7 (as ADC pins are PA0-7)
  channel &= 0b00000111;

  // Clear the old channel value (if any, last 5 bits in ADMUX)

  // Select the new channel in ADMUX

}

// Function to remap the ADC value to a new range
// old_low - old_high: corresponds to the ADC range (0-1023)
// new_low - new_high: corresponds to the new range (e.g., temperature range)
int16_t remap_interval(int16_t old_low, int16_t old_high, int16_t new_low, int16_t new_high, int16_t value)
{
  return new_low + (value - old_low) * (new_high - new_low) / (old_high - old_low);
}

//  TODO [task3]: Interrupt on ADC conversion complete (modify Duty Cycle here)
ISR(ADC_vect)
{

}

void timer0_init(void)
{
  TCCR0A = 0;
  TCCR0B = 0;

  /* TODO Task 3: set Fast PWM (8 bits) */

}

// Timer1 configured to trigger ISR every 1 second
void timer1_init(void)
{
  TCCR1A = 0;
  TCCR1B = 0;

  /* TODO Task 3: set Fast PWM (8 bits) */
  
}

/*DO NOT MODIFY*/
void task3(void)
{

  DDRB |= (1 << PB3);
  DDRD |= (1 << PD5);
  
  timer0_init();
  timer1_init();

  adc_free_running_init();
  configure_adc_channel(0);

  while (1);
}