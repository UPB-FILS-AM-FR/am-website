#ifndef SOUND_H
#define SOUND_H

#include <stdint.h>

extern const uint16_t surprise_notes[];
extern const uint8_t durations[];
extern const uint16_t notes_count;

#endif