#ifndef TIMERS_H
#define TIMERS_H

#include <stdint.h>

extern volatile uint32_t g_uptime_ms;

void uptime_init(void);

uint32_t uptime_ms(void);

#endif