#include "exenable.h"


#if  1 //NR_EX == 1


#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include <stdbool.h>

#include "usart.h"
#include "timers.h"
#include "sound.h"


volatile uint8_t green_duty = 0;   /* 0..188 for Timer2 manual PWM */
volatile uint8_t red_duty   = 0;   /* 0..255 */
volatile uint8_t blue_duty  = 0;   /* 0..255 */


/* ============================================================
 * GPIO
 * ============================================================ */

/**
 * Initialize the GPIOs of LEDs / speaker etc.
 */
int GPIO_init() {
    /* RGB led directions & default PORTs to 1 (OFF state) */
    DDRB |= (1 << PB3);
    DDRD |= (1 << PD5) | (1 << PD7);
    PORTB |= (1 << PB3);
    PORTD |= (1 << PD5) | (1 << PD7);
    return 0;
}


/* ============================================================
 * Green LED manual PWM using Timer2 COMPB
 * Period is fixed by OCR2A = 188.
 * Duty is controlled by OCR2B.
 * ============================================================ */


ISR(TIMER2_COMPA_vect)
{


    g_uptime_ms++;
    /* TODO(Task 2):
     * End of green LED OFF time.
     * Turn green LED ON here (set pin LOW).
     */


}


ISR(TIMER2_COMPB_vect)
{
    /* TODO(Task 2):
     * End of green LED ON time.
     * Turn green LED OFF here (set pin HIGH).
     */
}


static void green_set_duty(uint8_t duty)
{
    /* Duty range for manual PWM with Timer2 is 0..188 */
    if (duty > 188) {
        duty = 188;
    }

    green_duty = duty;
    OCR2B = duty;
}


/* ============================================================
 * Timer1 Fast PWM 8-bit on OC1A (PD5) -> RED LED
 * Active-low LED -> use inverting PWM
 * ============================================================ */
static void Timer1_init_red_pwm(void)
{
    /* Fast PWM 8-bit:
     * WGM13:0 = 0b0101
     * WGM10 = 1, WGM12 = 1
     */
    TCCR1A = 0;
    TCCR1B = 0;

    TCCR1A |= (1 << WGM10);
    TCCR1B |= (1 << WGM12);

    /* Inverting mode on OC1A:
     * COM1A1:0 = 0b11
     */
    TCCR1A |= (1 << COM1A1) | (1 << COM1A0); // COM1A1 for RED LED

    /* Prescaler = 64
     * PWM frequency ~= 12 MHz / 64 / 256 ~= 732 Hz
     */
    TCCR1B |= (1 << CS11) | (1 << CS10);

    /* Initial duty = 0 -> LED off */
    OCR1A = 0;
}

static void red_set_duty(uint8_t duty)
{
    red_duty = duty;

    /* In inverting mode for an active-low LED:
     * larger OCR1A -> longer LOW time -> brighter LED
     */
    OCR1A = duty;
}



/* ============================================================
 * Sound skeleton -- THIS IS ONLY FOR BONUS
 * ============================================================ */
extern const uint16_t surprise_notes[];
extern const uint8_t durations[];
extern const uint16_t notes_count;

static void speaker_stop(void)
{
    /* TODO(Task 5):
     * Disable speaker output
     */
}

static void speaker_set_frequency(uint16_t freq_hz)
{
    /* TODO(Task 5):
     * Reconfigure Timer1 for CTC mode
     * OCR1A -> TOP (frequency)
     * OCR1B = OCR1A / 2 for 50% duty
     * Output on OC1B (PD4)
     */
    (void)freq_hz;
}

static void update_notes(void)
{
    static uint32_t last_note_tick = 0;
    static uint16_t note_index = 0;

    uint32_t now = uptime_ms();

    if ((uint32_t)(now - last_note_tick) >= 25) {
        last_note_tick += 25;

        /* TODO(Task 5):
         * Advance current note duration here.
         * When needed:
         *   - load a new frequency from surprise_notes[]
         *   - configure timer with speaker_set_frequency(...)
         *   - reset TCNT1 = 0 after updating OCR values
         */

        (void)note_index;
    }
}

/* ============================================================
 * END OF Sound skeleton -- THIS IS ONLY FOR BONUS
 * ============================================================ */


int main(void)
{
    GPIO_init();
    USART0_init(9600);
    uptime_init();
    Timer1_init_red_pwm();

    sei();

    uint32_t last_msg = 0;
    uint8_t current_duty = 0;

    while (1) {
        uint32_t now = uptime_ms();

        if ((uint32_t)(now - last_msg) >= 1000) {
            last_msg += 1000;

            USART0_print("Uptime: ");
            USART0_print_u32(now);
            USART0_print(" ms\r\n");


            //TASK 1 - already done
            if(current_duty > 254){
                current_duty = 0;
            }

            red_set_duty(current_duty);
            
            current_duty += 64;
            
        }

        // TODO (Task 2)
        // call green_set_duty(duty_green)

        // TODO (Task 4): Use the previous defined function to read the ADC
        // value of the temperature sensor (PA0) and print it to the serial


    }
}

#endif