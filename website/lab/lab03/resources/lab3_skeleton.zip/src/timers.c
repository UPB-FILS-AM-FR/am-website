#include "timers.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#ifndef F_CPU
#define F_CPU 12000000UL
#endif

volatile uint32_t g_uptime_ms = 0;


void uptime_init(void)
{
    /* Timer2 CTC mode */
    TCCR2A = (1 << WGM21);
    TCCR2B = 0;

    /* 12MHz / 64 = 187500 Hz
       1ms ≈ 187.5 ticks
    */
    OCR2A = 187;

    TIMSK2 = (1 << OCIE2A);

    /* start timer with prescaler 64 */
    TCCR2B = (1 << CS22);
}

uint32_t uptime_ms(void)
{
    uint32_t t;
    uint8_t sreg = SREG;

    cli();
    t = g_uptime_ms;
    SREG = sreg;

    return t;
}


void Timer1_init_pwm()
{
    /* We must choose Fast PWM 8-bit, WGMn[3:0] = 0b0101 */
    /* Note: WGM11 and WGM10 are on TCCR1A, while WGM12 and WGM13 are on TCCR1B! */
    TCCR1A = (1 << WGM10);
    TCCR1B = (1 << WGM12);
    /* set COM1A to inverting output: COM1A[1:0] = 0b11 */
    TCCR1A |= (1 << COM1A1) | (1 << COM1A0);
    /* Use 64 prescaler: CS1[2:0] = 0b011 */
    TCCR1B |= (1 << CS10) | (1 << CS11);
    /* set duty cycle to 0%; note that we're using 8-bit mode, so TOP = 255 */
    OCR1A = 0;
}

void Timer1_init_ctc()
{
    /* TODO task 4 (bonus): use CTC mode to play tones (as 50% rectangular waves) */
    /* Clear them up, just to be sure ;) */
    TCCR1A = 0;
    TCCR1B = 0;
}