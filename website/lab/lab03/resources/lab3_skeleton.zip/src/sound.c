#include "sound.h"

/* Example placeholder melody */
const uint16_t surprise_notes[] = {
    262, 294, 330, 349, 392, 440, 494, 523
};

const uint8_t durations[] = {
    4, 4, 4, 4, 4, 4, 4, 8
};

const uint16_t notes_count = sizeof(surprise_notes) / sizeof(surprise_notes[0]);